﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Jarmuvek
{
    class Eladas
    {
        Jarmuvek jarmuvek;
        string vevo;
        int eladasiAr;

        public Eladas(Jarmuvek jarmuvek, string vevo, int eladasiAr)
        {
            this.jarmuvek = jarmuvek;
            this.vevo = vevo;
            this.eladasiAr = eladasiAr;
        }

        internal Jarmuvek Jarmuvek
        {
            get
            {
                return jarmuvek;
            }

            set
            {
                jarmuvek = value;
            }
        }

        public string Vevo
        {
            get
            {
                return vevo;
            }

            set
            {
                vevo = value;
            }
        }

        public int EladasiAr
        {
            get
            {
                return eladasiAr;
            }

            set
            {
                eladasiAr = value;
            }
        }

        public override string ToString()
        {
            return jarmuvek.ToString() + ";" + vevo + ";" + eladasiAr;
        }
    }
}
