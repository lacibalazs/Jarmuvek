﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Jarmuvek
{
    public partial class ErdeklodesForm : UjJarmuvekForm
    {
        Jarmuvek j;
        public ErdeklodesForm(Jarmuvek jarmuvek)
        {
            InitializeComponent();
            j = jarmuvek;
            tbMarka.Text = j.Marka;
            tbModell.Text = j.Modell;
            nudEvjarat.Value = j.Evjarat;
            tbUzemanyag.Text = j.Uzemanyag;
            nudKm.Value = j.Km;
            nudTeljesitmeny.Value = j.Teljesitmeny;
            nudAr.Value = j.Ar;
            tbTelefonszam.Text = j.Telefonszam;
            tbEmail.Text = j.Email;

            if (j is Auto)
            {
                Auto a = j as Auto;
                rbAuto.Checked = true;
                rbMotor.Visible = false;
                nudAjtok.Value = a.Ajtok;
                tbKlima.Text = a.Klima;
            }
            else
            {
                rbAuto.Visible = false;
                rbMotor.Checked = true;
                groupBox3.Visible = false;
                this.rbMotor.Location = new System.Drawing.Point(19, 540);
            }
        }

        private void rbErdeklodes_CheckedChanged(object sender, EventArgs e)
        {
            label2.Visible = !label2.Visible;
            nudEladasiAr.Visible = !nudEladasiAr.Visible;
        }

        protected override void Felvesz()
        {
            if (tbVevo.Text != "")
            {
                if (rbErdeklodes.Checked)
                {
                    j.Erdeklodok++;
                }
                else
                {
                    j.Eladva = true;
                    Eladas el = new Eladas(j, tbVevo.Text, Convert.ToInt32(nudEladasiAr.Value));
                    StreamWriter w = new StreamWriter("Eladasok.txt", true);
                    w.WriteLine(el.ToString());
                    w.Close();
                }
                DialogResult = DialogResult.OK;
            }
            else
            {
                MessageBox.Show("Kérem adja meg az érdeklődő/vevő nevét!");
            }
        }
    }
}
