﻿namespace Jarmuvek
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.lbJarmuvek = new System.Windows.Forms.ListBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.tbAzonosito = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.tbAr = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.tbTeljesitmeny = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.tbKm = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.tbEvjarat = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.tbUzemanyag = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.tbModell = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.tbMarka = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.újJárművekToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.érdeklődőkToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.tbEmail = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.tbTelefonszam = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.tbKlima = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.tbAjtok = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.labEladva = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tbErdeklodok = new System.Windows.Forms.TextBox();
            this.groupBox1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(76, 108);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(101, 18);
            this.label1.TabIndex = 0;
            this.label1.Text = "Összes jármű";
            // 
            // lbJarmuvek
            // 
            this.lbJarmuvek.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lbJarmuvek.FormattingEnabled = true;
            this.lbJarmuvek.ItemHeight = 18;
            this.lbJarmuvek.Location = new System.Drawing.Point(81, 131);
            this.lbJarmuvek.Margin = new System.Windows.Forms.Padding(4);
            this.lbJarmuvek.Name = "lbJarmuvek";
            this.lbJarmuvek.Size = new System.Drawing.Size(242, 562);
            this.lbJarmuvek.TabIndex = 1;
            this.lbJarmuvek.SelectedIndexChanged += new System.EventHandler(this.lbJarmuvek_SelectedIndexChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.tbAzonosito);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.tbAr);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.tbTeljesitmeny);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.tbKm);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.tbEvjarat);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.tbUzemanyag);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.tbModell);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.tbMarka);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Location = new System.Drawing.Point(434, 131);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(710, 224);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Jármű adatok";
            // 
            // tbAzonosito
            // 
            this.tbAzonosito.Location = new System.Drawing.Point(6, 53);
            this.tbAzonosito.Name = "tbAzonosito";
            this.tbAzonosito.Size = new System.Drawing.Size(201, 24);
            this.tbAzonosito.TabIndex = 17;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(3, 31);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(75, 18);
            this.label12.TabIndex = 16;
            this.label12.Text = "Azonosító";
            // 
            // tbAr
            // 
            this.tbAr.Location = new System.Drawing.Point(248, 175);
            this.tbAr.Name = "tbAr";
            this.tbAr.Size = new System.Drawing.Size(201, 24);
            this.tbAr.TabIndex = 15;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(245, 154);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(22, 18);
            this.label11.TabIndex = 14;
            this.label11.Text = "Ár";
            // 
            // tbTeljesitmeny
            // 
            this.tbTeljesitmeny.Location = new System.Drawing.Point(6, 175);
            this.tbTeljesitmeny.Name = "tbTeljesitmeny";
            this.tbTeljesitmeny.Size = new System.Drawing.Size(201, 24);
            this.tbTeljesitmeny.TabIndex = 13;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(3, 154);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(138, 18);
            this.label8.TabIndex = 12;
            this.label8.Text = "Teljesítmény (lóerő)";
            // 
            // tbKm
            // 
            this.tbKm.Location = new System.Drawing.Point(495, 110);
            this.tbKm.Name = "tbKm";
            this.tbKm.Size = new System.Drawing.Size(201, 24);
            this.tbKm.TabIndex = 11;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(492, 89);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(135, 18);
            this.label7.TabIndex = 10;
            this.label7.Text = "Kilóméteróra állása";
            // 
            // tbEvjarat
            // 
            this.tbEvjarat.Location = new System.Drawing.Point(6, 110);
            this.tbEvjarat.Name = "tbEvjarat";
            this.tbEvjarat.Size = new System.Drawing.Size(201, 24);
            this.tbEvjarat.TabIndex = 9;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(3, 89);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(53, 18);
            this.label6.TabIndex = 8;
            this.label6.Text = "Évjárat";
            // 
            // tbUzemanyag
            // 
            this.tbUzemanyag.Location = new System.Drawing.Point(248, 110);
            this.tbUzemanyag.Name = "tbUzemanyag";
            this.tbUzemanyag.Size = new System.Drawing.Size(201, 24);
            this.tbUzemanyag.TabIndex = 7;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(245, 89);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(87, 18);
            this.label5.TabIndex = 6;
            this.label5.Text = "Üzemanyag";
            // 
            // tbModell
            // 
            this.tbModell.Location = new System.Drawing.Point(495, 53);
            this.tbModell.Name = "tbModell";
            this.tbModell.Size = new System.Drawing.Size(201, 24);
            this.tbModell.TabIndex = 5;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(492, 32);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(52, 18);
            this.label4.TabIndex = 4;
            this.label4.Text = "Modell";
            // 
            // tbMarka
            // 
            this.tbMarka.Location = new System.Drawing.Point(248, 53);
            this.tbMarka.Name = "tbMarka";
            this.tbMarka.Size = new System.Drawing.Size(201, 24);
            this.tbMarka.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(245, 32);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(50, 18);
            this.label3.TabIndex = 2;
            this.label3.Text = "Márka";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.újJárművekToolStripMenuItem,
            this.érdeklődőkToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1219, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // újJárművekToolStripMenuItem
            // 
            this.újJárművekToolStripMenuItem.Name = "újJárművekToolStripMenuItem";
            this.újJárművekToolStripMenuItem.Size = new System.Drawing.Size(52, 20);
            this.újJárművekToolStripMenuItem.Text = "Eladás";
            this.újJárművekToolStripMenuItem.Click += new System.EventHandler(this.újJárművekToolStripMenuItem_Click);
            // 
            // érdeklődőkToolStripMenuItem
            // 
            this.érdeklődőkToolStripMenuItem.Name = "érdeklődőkToolStripMenuItem";
            this.érdeklődőkToolStripMenuItem.Size = new System.Drawing.Size(106, 20);
            this.érdeklődőkToolStripMenuItem.Text = "Vétel/Érdeklődés";
            this.érdeklődőkToolStripMenuItem.Click += new System.EventHandler(this.érdeklődőkToolStripMenuItem_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.tbEmail);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.tbTelefonszam);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Location = new System.Drawing.Point(434, 481);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(252, 165);
            this.groupBox2.TabIndex = 3;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Elérhetőség";
            // 
            // tbEmail
            // 
            this.tbEmail.Location = new System.Drawing.Point(9, 109);
            this.tbEmail.Name = "tbEmail";
            this.tbEmail.Size = new System.Drawing.Size(201, 24);
            this.tbEmail.TabIndex = 4;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(6, 88);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(50, 18);
            this.label10.TabIndex = 3;
            this.label10.Text = "E-mail";
            // 
            // tbTelefonszam
            // 
            this.tbTelefonszam.Location = new System.Drawing.Point(9, 53);
            this.tbTelefonszam.Name = "tbTelefonszam";
            this.tbTelefonszam.Size = new System.Drawing.Size(201, 24);
            this.tbTelefonszam.TabIndex = 2;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(6, 31);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(94, 18);
            this.label9.TabIndex = 1;
            this.label9.Text = "Telefonszám";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.tbKlima);
            this.groupBox3.Controls.Add(this.label14);
            this.groupBox3.Controls.Add(this.tbAjtok);
            this.groupBox3.Controls.Add(this.label13);
            this.groupBox3.Location = new System.Drawing.Point(680, 361);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(464, 90);
            this.groupBox3.TabIndex = 4;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Autó további adatai";
            this.groupBox3.Visible = false;
            // 
            // tbKlima
            // 
            this.tbKlima.Location = new System.Drawing.Point(248, 48);
            this.tbKlima.Name = "tbKlima";
            this.tbKlima.Size = new System.Drawing.Size(201, 24);
            this.tbKlima.TabIndex = 5;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(245, 27);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(87, 18);
            this.label14.TabIndex = 4;
            this.label14.Text = "Klíma fajtája";
            // 
            // tbAjtok
            // 
            this.tbAjtok.Location = new System.Drawing.Point(9, 48);
            this.tbAjtok.Name = "tbAjtok";
            this.tbAjtok.Size = new System.Drawing.Size(201, 24);
            this.tbAjtok.TabIndex = 3;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(6, 27);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(90, 18);
            this.label13.TabIndex = 2;
            this.label13.Text = "Ajtók száma";
            // 
            // labEladva
            // 
            this.labEladva.AutoSize = true;
            this.labEladva.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.labEladva.ForeColor = System.Drawing.Color.Red;
            this.labEladva.Location = new System.Drawing.Point(793, 534);
            this.labEladva.Name = "labEladva";
            this.labEladva.Size = new System.Drawing.Size(97, 31);
            this.labEladva.TabIndex = 5;
            this.labEladva.Text = "Eladva";
            this.labEladva.Visible = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(440, 388);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(133, 18);
            this.label2.TabIndex = 6;
            this.label2.Text = "Érdeklődők száma";
            // 
            // tbErdeklodok
            // 
            this.tbErdeklodok.Location = new System.Drawing.Point(440, 409);
            this.tbErdeklodok.Name = "tbErdeklodok";
            this.tbErdeklodok.Size = new System.Drawing.Size(201, 24);
            this.tbErdeklodok.TabIndex = 7;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1219, 727);
            this.Controls.Add(this.tbErdeklodok);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.labEladva);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.lbJarmuvek);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.menuStrip1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.Text = "Form1";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListBox lbJarmuvek;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox tbMarka;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tbEvjarat;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox tbUzemanyag;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tbModell;
        private System.Windows.Forms.TextBox tbTeljesitmeny;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox tbKm;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem újJárművekToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem érdeklődőkToolStripMenuItem;
        private System.Windows.Forms.TextBox tbAr;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox tbEmail;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox tbTelefonszam;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox tbAzonosito;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox tbKlima;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox tbAjtok;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label labEladva;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tbErdeklodok;
    }
}

