﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Jarmuvek
{
    public partial class UjJarmuvekForm : Form
    {
        Jarmuvek j;

        internal Jarmuvek J
        {
            get
            {
                return j;
            }

            set
            {
                j = value;
            }
        }

        public UjJarmuvekForm()
        {
            InitializeComponent();
        }

        private void rbAuto_CheckedChanged(object sender, EventArgs e)
        {
            groupBox3.Visible = !groupBox3.Visible;
        }

        private void btnRogzit_Click(object sender, EventArgs e)
        {
            Felvesz();
        }

        protected virtual void Felvesz()
        {
            if (tbMarka.Text != "" && tbModell.Text != "" && tbUzemanyag.Text != "" && tbTelefonszam.Text != "" && tbEmail.Text != "")
            {
                if (rbAuto.Checked)
                {
                    J = new Auto(tbMarka.Text, tbModell.Text, tbUzemanyag.Text, tbEmail.Text, Convert.ToInt32(nudEvjarat.Value), Convert.ToInt32(nudKm.Value), Convert.ToInt32(nudTeljesitmeny.Value), Convert.ToInt32(nudAr.Value), tbTelefonszam.Text, Convert.ToInt32(nudAjtok.Value), tbKlima.Text);
                }
                else
                {
                    J = new Jarmuvek(tbMarka.Text, tbModell.Text, tbUzemanyag.Text, tbEmail.Text, Convert.ToInt32(nudEvjarat.Value), Convert.ToInt32(nudKm.Value), Convert.ToInt32(nudTeljesitmeny.Value), Convert.ToInt32(nudAr.Value), tbTelefonszam.Text);
                }
                StreamWriter w = new StreamWriter("Jarmuvek.txt", true);
                w.WriteLine(J.ToString());
                w.Close();
                DialogResult = DialogResult.OK;
            }
            else
            {
                MessageBox.Show("Hiányzó adatok");
            }
        }
    }
}
