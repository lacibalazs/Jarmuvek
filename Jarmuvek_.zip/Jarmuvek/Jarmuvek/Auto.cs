﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Jarmuvek
{
    class Auto:Jarmuvek
    {
        int ajtok;
        string klima;

        public Auto(string azonosito, string marka, string modell, string uzemanyag, string email, int evjarat, int km, int teljesitmeny, int ar, string telefonszam, int ajtok, string klima, bool eladva, int erdeklodok) : base(azonosito, marka, modell, uzemanyag, email, evjarat, km, teljesitmeny, ar, telefonszam, eladva, erdeklodok)
        {
            this.Ajtok = ajtok;
            this.Klima = klima;
        }

        public Auto(string marka, string modell, string uzemanyag, string email, int evjarat, int km, int teljesitmeny, int ar, string telefonszam, int ajtok, string klima) : base(marka, modell, uzemanyag, email, evjarat, km, teljesitmeny, ar, telefonszam)
        {
            this.Ajtok = ajtok;
            this.Klima = klima;
        }

        public int Ajtok
        {
            get
            {
                return ajtok;
            }

            set
            {
                ajtok = value;
            }
        }

        public string Klima
        {
            get
            {
                return klima;
            }

            set
            {
                klima = value;
            }
        }
        public override string ToString()
        {
            return azonosito + ";" + marka + ";" + modell + ";" + uzemanyag + ";" + email + ";" + evjarat + ";" + km + ";" + teljesitmeny + ";" + ar + ";" + telefonszam + ";" + ajtok + ";" + klima + ";" + eladva + ";" + erdeklodok;
        }
    }
}
