﻿namespace Jarmuvek
{
    partial class UjJarmuvekForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.nudAr = new System.Windows.Forms.NumericUpDown();
            this.nudTeljesitmeny = new System.Windows.Forms.NumericUpDown();
            this.nudKm = new System.Windows.Forms.NumericUpDown();
            this.nudEvjarat = new System.Windows.Forms.NumericUpDown();
            this.label11 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.tbUzemanyag = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.tbModell = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.tbMarka = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.nudAjtok = new System.Windows.Forms.NumericUpDown();
            this.tbKlima = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.rbAuto = new System.Windows.Forms.RadioButton();
            this.rbMotor = new System.Windows.Forms.RadioButton();
            this.btnRogzit = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.tbEmail = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.tbTelefonszam = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudAr)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudTeljesitmeny)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudKm)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudEvjarat)).BeginInit();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudAjtok)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.nudAr);
            this.groupBox1.Controls.Add(this.nudTeljesitmeny);
            this.groupBox1.Controls.Add(this.nudKm);
            this.groupBox1.Controls.Add(this.nudEvjarat);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.tbUzemanyag);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.tbModell);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.tbMarka);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Location = new System.Drawing.Point(13, 45);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(246, 467);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Jármű adatok";
            // 
            // nudAr
            // 
            this.nudAr.Location = new System.Drawing.Point(6, 430);
            this.nudAr.Maximum = new decimal(new int[] {
            -469762049,
            -590869294,
            5421010,
            0});
            this.nudAr.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudAr.Name = "nudAr";
            this.nudAr.Size = new System.Drawing.Size(201, 24);
            this.nudAr.TabIndex = 32;
            this.nudAr.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // nudTeljesitmeny
            // 
            this.nudTeljesitmeny.Location = new System.Drawing.Point(6, 370);
            this.nudTeljesitmeny.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.nudTeljesitmeny.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudTeljesitmeny.Name = "nudTeljesitmeny";
            this.nudTeljesitmeny.Size = new System.Drawing.Size(201, 24);
            this.nudTeljesitmeny.TabIndex = 31;
            this.nudTeljesitmeny.Value = new decimal(new int[] {
            100,
            0,
            0,
            0});
            // 
            // nudKm
            // 
            this.nudKm.Location = new System.Drawing.Point(6, 306);
            this.nudKm.Maximum = new decimal(new int[] {
            -1304428545,
            434162106,
            542,
            0});
            this.nudKm.Name = "nudKm";
            this.nudKm.Size = new System.Drawing.Size(201, 24);
            this.nudKm.TabIndex = 30;
            // 
            // nudEvjarat
            // 
            this.nudEvjarat.Location = new System.Drawing.Point(6, 177);
            this.nudEvjarat.Maximum = new decimal(new int[] {
            2021,
            0,
            0,
            0});
            this.nudEvjarat.Minimum = new decimal(new int[] {
            1900,
            0,
            0,
            0});
            this.nudEvjarat.Name = "nudEvjarat";
            this.nudEvjarat.Size = new System.Drawing.Size(201, 24);
            this.nudEvjarat.TabIndex = 29;
            this.nudEvjarat.Value = new decimal(new int[] {
            2000,
            0,
            0,
            0});
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(3, 409);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(22, 18);
            this.label11.TabIndex = 28;
            this.label11.Text = "Ár";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(3, 349);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(138, 18);
            this.label8.TabIndex = 26;
            this.label8.Text = "Teljesítmény (lóerő)";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(3, 285);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(135, 18);
            this.label7.TabIndex = 24;
            this.label7.Text = "Kilóméteróra állása";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(3, 155);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(53, 18);
            this.label6.TabIndex = 22;
            this.label6.Text = "Évjárat";
            // 
            // tbUzemanyag
            // 
            this.tbUzemanyag.Location = new System.Drawing.Point(6, 241);
            this.tbUzemanyag.Name = "tbUzemanyag";
            this.tbUzemanyag.Size = new System.Drawing.Size(201, 24);
            this.tbUzemanyag.TabIndex = 21;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(3, 220);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(87, 18);
            this.label5.TabIndex = 20;
            this.label5.Text = "Üzemanyag";
            // 
            // tbModell
            // 
            this.tbModell.Location = new System.Drawing.Point(6, 116);
            this.tbModell.Name = "tbModell";
            this.tbModell.Size = new System.Drawing.Size(201, 24);
            this.tbModell.TabIndex = 19;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(3, 95);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(52, 18);
            this.label4.TabIndex = 18;
            this.label4.Text = "Modell";
            // 
            // tbMarka
            // 
            this.tbMarka.Location = new System.Drawing.Point(6, 57);
            this.tbMarka.Name = "tbMarka";
            this.tbMarka.Size = new System.Drawing.Size(201, 24);
            this.tbMarka.TabIndex = 17;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(3, 36);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(50, 18);
            this.label3.TabIndex = 16;
            this.label3.Text = "Márka";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.nudAjtok);
            this.groupBox3.Controls.Add(this.tbKlima);
            this.groupBox3.Controls.Add(this.label14);
            this.groupBox3.Controls.Add(this.label13);
            this.groupBox3.Location = new System.Drawing.Point(313, 239);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(252, 149);
            this.groupBox3.TabIndex = 5;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Autó további adatai";
            this.groupBox3.Visible = false;
            // 
            // nudAjtok
            // 
            this.nudAjtok.Location = new System.Drawing.Point(9, 48);
            this.nudAjtok.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudAjtok.Name = "nudAjtok";
            this.nudAjtok.Size = new System.Drawing.Size(201, 24);
            this.nudAjtok.TabIndex = 32;
            this.nudAjtok.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // tbKlima
            // 
            this.tbKlima.Location = new System.Drawing.Point(9, 108);
            this.tbKlima.Name = "tbKlima";
            this.tbKlima.Size = new System.Drawing.Size(201, 24);
            this.tbKlima.TabIndex = 5;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(6, 87);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(87, 18);
            this.label14.TabIndex = 4;
            this.label14.Text = "Klíma fajtája";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(6, 27);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(90, 18);
            this.label13.TabIndex = 2;
            this.label13.Text = "Ajtók száma";
            // 
            // rbAuto
            // 
            this.rbAuto.AutoSize = true;
            this.rbAuto.Location = new System.Drawing.Point(19, 540);
            this.rbAuto.Name = "rbAuto";
            this.rbAuto.Size = new System.Drawing.Size(56, 22);
            this.rbAuto.TabIndex = 6;
            this.rbAuto.Text = "Autó";
            this.rbAuto.UseVisualStyleBackColor = true;
            this.rbAuto.CheckedChanged += new System.EventHandler(this.rbAuto_CheckedChanged);
            // 
            // rbMotor
            // 
            this.rbMotor.AutoSize = true;
            this.rbMotor.Checked = true;
            this.rbMotor.Location = new System.Drawing.Point(19, 569);
            this.rbMotor.Name = "rbMotor";
            this.rbMotor.Size = new System.Drawing.Size(124, 22);
            this.rbMotor.TabIndex = 7;
            this.rbMotor.TabStop = true;
            this.rbMotor.Text = "Motorkerékpár";
            this.rbMotor.UseVisualStyleBackColor = true;
            // 
            // btnRogzit
            // 
            this.btnRogzit.Location = new System.Drawing.Point(313, 540);
            this.btnRogzit.Name = "btnRogzit";
            this.btnRogzit.Size = new System.Drawing.Size(210, 51);
            this.btnRogzit.TabIndex = 8;
            this.btnRogzit.Text = "Rögzítés";
            this.btnRogzit.UseVisualStyleBackColor = true;
            this.btnRogzit.Click += new System.EventHandler(this.btnRogzit_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.tbEmail);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.tbTelefonszam);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Location = new System.Drawing.Point(313, 45);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(252, 165);
            this.groupBox2.TabIndex = 9;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Elérhetőség";
            // 
            // tbEmail
            // 
            this.tbEmail.Location = new System.Drawing.Point(9, 109);
            this.tbEmail.Name = "tbEmail";
            this.tbEmail.Size = new System.Drawing.Size(201, 24);
            this.tbEmail.TabIndex = 4;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(6, 88);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(50, 18);
            this.label10.TabIndex = 3;
            this.label10.Text = "E-mail";
            // 
            // tbTelefonszam
            // 
            this.tbTelefonszam.Location = new System.Drawing.Point(9, 53);
            this.tbTelefonszam.Name = "tbTelefonszam";
            this.tbTelefonszam.Size = new System.Drawing.Size(201, 24);
            this.tbTelefonszam.TabIndex = 2;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(6, 31);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(94, 18);
            this.label9.TabIndex = 1;
            this.label9.Text = "Telefonszám";
            // 
            // UjJarmuvekForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(572, 612);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.btnRogzit);
            this.Controls.Add(this.rbMotor);
            this.Controls.Add(this.rbAuto);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "UjJarmuvekForm";
            this.Text = "UjJarmuvekForm";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudAr)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudTeljesitmeny)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudKm)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudEvjarat)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudAjtok)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        protected System.Windows.Forms.GroupBox groupBox1;
        protected System.Windows.Forms.NumericUpDown nudAr;
        protected System.Windows.Forms.NumericUpDown nudTeljesitmeny;
        protected System.Windows.Forms.NumericUpDown nudKm;
        protected System.Windows.Forms.NumericUpDown nudEvjarat;
        protected System.Windows.Forms.Label label11;
        protected System.Windows.Forms.Label label8;
        protected System.Windows.Forms.Label label7;
        protected System.Windows.Forms.Label label6;
        protected System.Windows.Forms.TextBox tbUzemanyag;
        protected System.Windows.Forms.Label label5;
        protected System.Windows.Forms.TextBox tbModell;
        protected System.Windows.Forms.Label label4;
        protected System.Windows.Forms.TextBox tbMarka;
        protected System.Windows.Forms.Label label3;
        protected System.Windows.Forms.GroupBox groupBox3;
        protected System.Windows.Forms.NumericUpDown nudAjtok;
        protected System.Windows.Forms.TextBox tbKlima;
        protected System.Windows.Forms.Label label14;
        protected System.Windows.Forms.Label label13;
        protected System.Windows.Forms.RadioButton rbAuto;
        protected System.Windows.Forms.RadioButton rbMotor;
        protected System.Windows.Forms.Button btnRogzit;
        protected System.Windows.Forms.GroupBox groupBox2;
        protected System.Windows.Forms.TextBox tbEmail;
        protected System.Windows.Forms.Label label10;
        protected System.Windows.Forms.TextBox tbTelefonszam;
        protected System.Windows.Forms.Label label9;
    }
}