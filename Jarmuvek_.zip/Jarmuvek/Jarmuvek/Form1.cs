﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Jarmuvek
{
    public partial class Form1 : Form
    {
        List<Jarmuvek> jarmuvek = new List<Jarmuvek>();
        public Form1()
        {
            InitializeComponent();
            Beolvas();
        }

        private void Beolvas()
        {
            if (File.Exists("Jarmuvek.txt"))
            {
                StreamReader r = new StreamReader("Jarmuvek.txt");
                while (!r.EndOfStream)
                {
                    Jarmuvek j;
                    string[] s = r.ReadLine().Split(';');
                    if (s.Length == 12)
                    {
                        j = new Jarmuvek(s[0], s[1], s[2], s[3], s[4], Convert.ToInt32(s[5]), Convert.ToInt32(s[6]), Convert.ToInt32(s[7]), Convert.ToInt32(s[8]), s[9], Convert.ToBoolean(s[10]), Convert.ToInt32(s[11]));
                    }
                    else
                    {
                        j = new Auto(s[0], s[1], s[2], s[3], s[4], Convert.ToInt32(s[5]), Convert.ToInt32(s[6]), Convert.ToInt32(s[7]), Convert.ToInt32(s[8]), s[9], Convert.ToInt32(s[10]), s[11], Convert.ToBoolean(s[12]), Convert.ToInt32(s[13]));
                    }
                    jarmuvek.Add(j);
                    lbJarmuvek.Items.Add(j.Azonosito + "\t" + j.Marka + "\t" + j.Modell);
                }
                r.Close();
                Jarmuvek.Szam = jarmuvek.Count;
            }
        }

        private void újJárművekToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UjJarmuvekForm uj = new UjJarmuvekForm();
            if (uj.ShowDialog() == DialogResult.OK)
            {
                jarmuvek.Add(uj.J);
                lbJarmuvek.Items.Add(uj.J.Azonosito + "\t" + uj.J.Marka + "\t" + uj.J.Modell);
            }
        }

        private void lbJarmuvek_SelectedIndexChanged(object sender, EventArgs e)
        {
            Kiir();
        }

        private void érdeklődőkToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (lbJarmuvek.SelectedIndex >= 0)
            {
                Jarmuvek j = jarmuvek[lbJarmuvek.SelectedIndex];
                if (!j.Eladva)
                {
                    ErdeklodesForm uj = new ErdeklodesForm(j);
                    if (uj.ShowDialog() == DialogResult.OK)
                    {
                        Kiir();
                        if(j.Eladva)
                        {
                            FileIras();
                        }
                    }
                }
                else
                {
                    MessageBox.Show("A jármű már értékesítve lett!");
                }
            }
            else
            {
                MessageBox.Show("Nincs jármű kiválasztva!");
            }
        }

        private void Kiir()
        {
            if (lbJarmuvek.SelectedIndex >= 0)
            {
                tbAzonosito.Text = jarmuvek[lbJarmuvek.SelectedIndex].Azonosito;
                tbMarka.Text = jarmuvek[lbJarmuvek.SelectedIndex].Marka;
                tbModell.Text = jarmuvek[lbJarmuvek.SelectedIndex].Modell;
                tbEvjarat.Text = jarmuvek[lbJarmuvek.SelectedIndex].Evjarat.ToString();
                tbUzemanyag.Text = jarmuvek[lbJarmuvek.SelectedIndex].Uzemanyag;
                tbKm.Text = jarmuvek[lbJarmuvek.SelectedIndex].Km.ToString();
                tbTeljesitmeny.Text = jarmuvek[lbJarmuvek.SelectedIndex].Teljesitmeny.ToString();
                tbAr.Text = jarmuvek[lbJarmuvek.SelectedIndex].Ar.ToString();
                tbTelefonszam.Text = jarmuvek[lbJarmuvek.SelectedIndex].Telefonszam;
                tbEmail.Text = jarmuvek[lbJarmuvek.SelectedIndex].Email;
                tbErdeklodok.Text = jarmuvek[lbJarmuvek.SelectedIndex].Erdeklodok.ToString();

                if (jarmuvek[lbJarmuvek.SelectedIndex] is Auto)
                {
                    groupBox3.Visible = true;
                    Auto a = jarmuvek[lbJarmuvek.SelectedIndex] as Auto;
                    tbAjtok.Text = a.Ajtok.ToString();
                    tbKlima.Text = a.Klima;
                }
                else
                {
                    groupBox3.Visible = false;
                }
                if (jarmuvek[lbJarmuvek.SelectedIndex].Eladva)
                {
                    labEladva.Visible = true;
                }
                else
                {
                    labEladva.Visible = false;
                }
            }
        }
        private void FileIras()
        {
            if (File.Exists("Jarmuvek.txt"))
            {
                StreamWriter w = new StreamWriter("Jarmuvek.txt");
                {
                    foreach (Jarmuvek j in jarmuvek)
                    {
                        w.WriteLine(j.ToString());
                    }
                }
                w.Close();
            }
        }
    }
}
