﻿namespace Jarmuvek
{
    partial class ErdeklodesForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.rbEladas = new System.Windows.Forms.RadioButton();
            this.rbErdeklodes = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tbVevo = new System.Windows.Forms.TextBox();
            this.nudEladasiAr = new System.Windows.Forms.NumericUpDown();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudAr)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudTeljesitmeny)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudKm)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudEvjarat)).BeginInit();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudAjtok)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudEladasiAr)).BeginInit();
            this.SuspendLayout();
            // 
            // nudAr
            // 
            this.nudAr.ReadOnly = true;
            // 
            // nudTeljesitmeny
            // 
            this.nudTeljesitmeny.ReadOnly = true;
            // 
            // nudKm
            // 
            this.nudKm.ReadOnly = true;
            // 
            // nudEvjarat
            // 
            this.nudEvjarat.ReadOnly = true;
            // 
            // tbUzemanyag
            // 
            this.tbUzemanyag.Margin = new System.Windows.Forms.Padding(4);
            this.tbUzemanyag.ReadOnly = true;
            // 
            // tbModell
            // 
            this.tbModell.Margin = new System.Windows.Forms.Padding(4);
            this.tbModell.ReadOnly = true;
            // 
            // tbMarka
            // 
            this.tbMarka.Margin = new System.Windows.Forms.Padding(4);
            this.tbMarka.ReadOnly = true;
            // 
            // nudAjtok
            // 
            this.nudAjtok.ReadOnly = true;
            // 
            // tbKlima
            // 
            this.tbKlima.Margin = new System.Windows.Forms.Padding(4);
            this.tbKlima.ReadOnly = true;
            // 
            // btnRogzit
            // 
            this.btnRogzit.Location = new System.Drawing.Point(664, 286);
            // 
            // tbEmail
            // 
            this.tbEmail.Margin = new System.Windows.Forms.Padding(4);
            this.tbEmail.ReadOnly = true;
            // 
            // tbTelefonszam
            // 
            this.tbTelefonszam.Margin = new System.Windows.Forms.Padding(4);
            this.tbTelefonszam.ReadOnly = true;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.rbEladas);
            this.groupBox4.Controls.Add(this.rbErdeklodes);
            this.groupBox4.Location = new System.Drawing.Point(658, 45);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(251, 100);
            this.groupBox4.TabIndex = 10;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Érdeklődés vagy eladás jegyzése";
            // 
            // rbEladas
            // 
            this.rbEladas.AutoSize = true;
            this.rbEladas.Checked = true;
            this.rbEladas.Location = new System.Drawing.Point(6, 58);
            this.rbEladas.Name = "rbEladas";
            this.rbEladas.Size = new System.Drawing.Size(71, 22);
            this.rbEladas.TabIndex = 1;
            this.rbEladas.TabStop = true;
            this.rbEladas.Text = "Eladás";
            this.rbEladas.UseVisualStyleBackColor = true;
            // 
            // rbErdeklodes
            // 
            this.rbErdeklodes.AutoSize = true;
            this.rbErdeklodes.Location = new System.Drawing.Point(6, 29);
            this.rbErdeklodes.Name = "rbErdeklodes";
            this.rbErdeklodes.Size = new System.Drawing.Size(101, 22);
            this.rbErdeklodes.TabIndex = 0;
            this.rbErdeklodes.Text = "Érdeklődés";
            this.rbErdeklodes.UseVisualStyleBackColor = true;
            this.rbErdeklodes.CheckedChanged += new System.EventHandler(this.rbErdeklodes_CheckedChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(661, 158);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(148, 18);
            this.label1.TabIndex = 11;
            this.label1.Text = "Érdeklődő/Vevő neve";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(661, 217);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(73, 18);
            this.label2.TabIndex = 12;
            this.label2.Text = "Eladási ár";
            // 
            // tbVevo
            // 
            this.tbVevo.Location = new System.Drawing.Point(664, 176);
            this.tbVevo.Name = "tbVevo";
            this.tbVevo.Size = new System.Drawing.Size(100, 24);
            this.tbVevo.TabIndex = 13;
            // 
            // nudEladasiAr
            // 
            this.nudEladasiAr.Location = new System.Drawing.Point(664, 239);
            this.nudEladasiAr.Name = "nudEladasiAr";
            this.nudEladasiAr.Size = new System.Drawing.Size(120, 24);
            this.nudEladasiAr.TabIndex = 14;
            // 
            // ErdeklodesForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1059, 636);
            this.Controls.Add(this.nudEladasiAr);
            this.Controls.Add(this.tbVevo);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.groupBox4);
            this.Margin = new System.Windows.Forms.Padding(6);
            this.Name = "ErdeklodesForm";
            this.Text = "ErdeklodesForm";
            this.Controls.SetChildIndex(this.groupBox1, 0);
            this.Controls.SetChildIndex(this.groupBox3, 0);
            this.Controls.SetChildIndex(this.rbAuto, 0);
            this.Controls.SetChildIndex(this.rbMotor, 0);
            this.Controls.SetChildIndex(this.btnRogzit, 0);
            this.Controls.SetChildIndex(this.groupBox2, 0);
            this.Controls.SetChildIndex(this.groupBox4, 0);
            this.Controls.SetChildIndex(this.label1, 0);
            this.Controls.SetChildIndex(this.label2, 0);
            this.Controls.SetChildIndex(this.tbVevo, 0);
            this.Controls.SetChildIndex(this.nudEladasiAr, 0);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudAr)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudTeljesitmeny)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudKm)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudEvjarat)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudAjtok)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudEladasiAr)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.RadioButton rbEladas;
        private System.Windows.Forms.RadioButton rbErdeklodes;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tbVevo;
        private System.Windows.Forms.NumericUpDown nudEladasiAr;
    }
}