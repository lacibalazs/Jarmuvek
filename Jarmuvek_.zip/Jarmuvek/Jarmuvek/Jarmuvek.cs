﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Jarmuvek
{
    public class Jarmuvek
    {
        static int szam = 0;
        protected string azonosito, marka, modell, uzemanyag, email, telefonszam;
        protected int evjarat, km, teljesitmeny, ar, erdeklodok;
        protected bool eladva;

        public Jarmuvek (string azonosito, string marka, string modell, string uzemanyag, string email, int evjarat, int km, int teljesitmeny, int ar, string telefonszam, bool eladva, int erdeklodok)
        {
            this.azonosito = azonosito;
            this.marka = marka;
            this.modell = modell;
            this.uzemanyag = uzemanyag;
            this.email = email;
            this.evjarat = evjarat;
            this.km = km;
            this.teljesitmeny = teljesitmeny;
            this.ar = ar;
            this.telefonszam = telefonszam;
            this.eladva = eladva;
            this.erdeklodok = erdeklodok;
        }

        public Jarmuvek (string marka, string modell, string uzemanyag, string email, int evjarat, int km, int teljesitmeny, int ar, string telefonszam)
        {
            this.azonosito = (++Szam).ToString();
            this.marka = marka;
            this.modell = modell;
            this.uzemanyag = uzemanyag;
            this.email = email;
            this.evjarat = evjarat;
            this.km = km;
            this.teljesitmeny = teljesitmeny;
            this.ar = ar;
            this.telefonszam = telefonszam;
        }


        
        public string Email
        {
            get
            {
                return email;
            }

            set
            {
                email = value;
            }
        }

        public string Azonosito
        {
            get
            {
                return azonosito;
            }

            set
            {
                azonosito = value;
            }
        }

        public string Marka
        {
            get
            {
                return marka;
            }

            set
            {
                marka = value;
            }
        }

        public string Modell
        {
            get
            {
                return modell;
            }

            set
            {
                modell = value;
            }
        }

        public string Uzemanyag
        {
            get
            {
                return uzemanyag;
            }

            set
            {
                uzemanyag = value;
            }
        }

        public int Evjarat
        {
            get
            {
                return evjarat;
            }

            set
            {
                evjarat = value;
            }
        }

        public int Km
        {
            get
            {
                return km;
            }

            set
            {
                km = value;
            }
        }

        public int Teljesitmeny
        {
            get
            {
                return teljesitmeny;
            }

            set
            {
                teljesitmeny = value;
            }
        }

        public int Ar
        {
            get
            {
                return ar;
            }

            set
            {
                ar = value;
            }
        }

        public int Erdeklodok
        {
            get
            {
                return erdeklodok;
            }

            set
            {
                erdeklodok = value;
            }
        }

        public string Telefonszam
        {
            get
            {
                return telefonszam;
            }

            set
            {
                telefonszam = value;
            }
        }

        public bool Eladva
        {
            get
            {
                return eladva;
            }

            set
            {
                eladva = value;
            }
        }

        public static int Szam
        {
            get
            {
                return szam;
            }

            set
            {
                szam = value;
            }
        }

        public override string ToString()
        {
            return azonosito + ";" + marka + ";" + modell + ";" + uzemanyag + ";" + email + ";" + evjarat + ";" + km + ";" + teljesitmeny + ";" + ar + ";" + telefonszam + ";" + eladva + ";" + erdeklodok;
        }
    }
}
